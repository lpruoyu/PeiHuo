package wb.lp.peihuo.data;

import java.util.Objects;

import wb.lp.peihuo.ConfirmActivity;

public class SubItem {
    private String mendian;
    private String danwei;
    private double count;

    private double weight = -1;
//是否配了
    private boolean isPei;

    public double getWeight() {
        if (this.weight == -1) this.weight = getW();
        return weight;
    }

    @Override
    public String toString() {
        return mendian + "\t" + count + "\t" + (danwei == null ? "" : danwei);
    }


    public double getW() {


        if(ConfirmActivity.MDS.contains(mendian)) {
            return ConfirmActivity.MDS.indexOf(mendian);
        }

        return -1;
    }


//    public double getW() {
//        if (MainActivity.SY.equals(mendian)) return 0;
//        if (MainActivity.YH.equals(mendian)) return 1;
//        if (MainActivity.WD.equals(mendian)) return 2;
//        if (MainActivity.XQG.equals(mendian)) return 3;
//        if (MainActivity.HT.equals(mendian)) return 4;
//        if (MainActivity.LM.equals(mendian)) return 5;
//        if (MainActivity.QB.equals(mendian)) return 6;
//        if (MainActivity.JH.equals(mendian)) return 7;
//        if (MainActivity.QJ.equals(mendian)) return 8;
//        return -1;
//    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        SubItem subItem = (SubItem) o;
        return Double.compare(weight, subItem.weight) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(weight);
    }

    public String getMendian() {
        return mendian;
    }

    public void setMendian(String mendian) {
        this.mendian = mendian;
    }

    public String getDanwei() {
        return danwei;
    }

    public void setDanwei(String danwei) {
        this.danwei = danwei;
    }

    public double getCount() {
        return count;
    }

    public void setCount(double count) {
        this.count = count;
    }
}
