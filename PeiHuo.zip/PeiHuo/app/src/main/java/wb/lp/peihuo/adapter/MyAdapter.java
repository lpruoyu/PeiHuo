package wb.lp.peihuo.adapter;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.Gson;

import java.util.List;

import wb.lp.peihuo.R;
import wb.lp.peihuo.SubActivity;
import wb.lp.peihuo.data.AllItem;

public class MyAdapter extends ArrayAdapter<AllItem> {

    private List<AllItem> objects;
    private int resource;

    public List<AllItem> getObjects() {
        return objects;
    }

    public MyAdapter(@NonNull Context context, int resource, @NonNull List<AllItem> objects) {
        super(context, resource, objects);
        this.objects = objects;
        this.resource = resource;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
//        if(convertView!=null) convertView.setBackgroundResource(objects.get(position).getColor());
//        else {
//            view.setBackgroundResource(objects.get(position).getColor());
//        }

        View view;
        view = LayoutInflater.from(getContext()).inflate(resource, parent, false);

//        if (convertView == null) {
//            view = LayoutInflater.from(getContext()).inflate(resource, parent, false);
//        } else {
//            view = convertView;
//        }
        CheckBox checkBox = view.findViewById(R.id.ph_choice);
        checkBox.setChecked(objects.get(position).isChecked());
        TextView textView = view.findViewById(R.id.ph_text);
        textView.setText(objects.get(position).toString());

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull CompoundButton buttonView, boolean isChecked) {
                objects.get(position).setChecked(isChecked);
            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Log.d("xxx","点击");
                if (((CheckBox) v.findViewById(R.id.ph_choice)).isChecked()) {


//                    Log.d("xxx","点击进入");
                    Intent intent = new Intent();
                    intent.setClass(getContext(), SubActivity.class);
                    Gson gson = new Gson();
                    String json = gson.toJson(objects.get(position));
                    intent.putExtra("data", json);
//                    getContext().startActivity(intent);
                    ((Activity) getContext()).startActivityForResult(intent, objects.get(position).getRequestCode());
                }
            }
        });

        view.setBackgroundColor(Color.parseColor(objects.get(position).getColor()));
//        view.setBackgroundColor(Color.parseColor(objects.get(position).getColor()));
        return view;
    }

}
